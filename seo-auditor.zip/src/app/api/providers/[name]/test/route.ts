// Test live connection for a provider.
import { validateProviderByKey } from '@/lib/store/providers';
import { getProvider } from '@/lib/providers/registry';

export const dynamic = 'force-dynamic';
export const maxDuration = 60;

export async function POST(_req: Request, { params }: { params: Promise<{ name: string }> }) {
  const { name: providerKey } = await params;
  const provider = getProvider(providerKey);
  if (!provider) {
    return Response.json({ error: `Unknown provider: ${providerKey}` }, { status: 404 });
  }
  try {
    const result = await validateProviderByKey(providerKey);
    return Response.json({ result });
  } catch (err) {
    return Response.json({ error: `Validation failed: ${(err as Error).message}` }, { status: 500 });
  }
}
